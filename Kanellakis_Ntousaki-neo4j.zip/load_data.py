'''
@authors: KosmasKanellakis (t8200053), IoannaNtousaki (t8200125)
'''

from neo4j import GraphDatabase

uri = "bolt://localhost:7687"  # Replace with your Neo4j server URI
username = "xxxxxxxxx"     # Replace with your Neo4j username
password = "xxxxxxxxx"     # Replace with your Neo4j password

# Connent to neo4j 
driver = GraphDatabase.driver(uri, auth=(username, password))

def load_data_to_neo4j():
    
    # Create the three node categories: User, Action & Target
    with open('mooc_actions.tsv', 'r') as actions_file:
        
        # Skip the header line
        actions_file.readline()
        for line in actions_file:
            action_id, user_id, target_id, timestamp = line.strip().split('\t')
            
            # Create cypher commands
            create_user_query = f"MERGE (u:User {{user_id: {user_id}}})"
            create_target_query = f"MERGE (t:Target {{target_id: {target_id}}})"
            create_action_query = f"CREATE (a:Action {{action_id: {action_id}, timestamp: {timestamp}}})"
            
            create_relationship_query = f"MATCH (u:User {{user_id: {user_id}}}), (t:Target {{target_id: {target_id}}}), (a:Action {{action_id: {action_id}}}) CREATE (u)-[:PERFORMED {{timestamp: {timestamp}}}]->(a)-[:ACTED_ON]->(t)"
            # Run cypher commands
            with driver.session() as session:
                session.run(create_user_query)
                session.run(create_target_query)
                session.run(create_action_query)
                session.run(create_relationship_query)

    # Add the 3 features into action nodes 
    with open('mooc_action_features.tsv', 'r') as features_file:
        # Skip the header line
        features_file.readline()
        for line in features_file:
            
            # Create cypher command
            action_id, *features = line.strip().split('\t')
            set_features_query = f"MATCH (a:Action {{action_id: {action_id}}}) SET a += {{feature0: {features[0]}, feature1: {features[1]}, feature2: {features[2]}, feature3: {features[3]}}}"
            # Run cypher query
            with driver.session() as session:
                session.run(set_features_query)
    # Add label into action nodes
    with open('mooc_action_labels.tsv', 'r') as labels_file:
        # Skip the header line
        labels_file.readline()
        for line in labels_file:
            
            # Create cypher command
            action_id, label = line.strip().split('\t')
            set_label_query = f"MATCH (a:Action {{action_id: {action_id}}}) SET a += {{label: {label}}}"
            
            # Run cypher query
            with driver.session() as session:
                session.run(set_label_query)
                
# Run data loading function
load_data_to_neo4j()